from tkinter import Tk, font

root = Tk()
font_families = font.families()
print(font_families)
root.destroy()